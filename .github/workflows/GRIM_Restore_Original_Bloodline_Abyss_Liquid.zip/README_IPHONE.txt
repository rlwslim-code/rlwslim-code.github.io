GRIM — Restore the original Bloodline Red x Abyss Blue liquid touch

WHY
The newer GRIM Global Liquid Glass V1 added subtle gold glints/ripples. This
workflow removes only the V1 CSS/JS references from current HTML pages, and
ensures the earlier two-dye flowing fluid effect is loaded throughout GRIM.
No website HTML files are replaced, and checkout, payments, admin, notify,
wallet and existing content stay in place.

ON IPHONE (normally ONE FILE ONLY)
1. Extract this ZIP in the Files app.
2. In your GitHub repo on main, upload:
   .github/workflows/grim-restore-bloodline-abyss.yml
   Keep the .github/workflows/ directory structure at the repository root.
3. Go to Actions > GRIM | Restore Bloodline Abyss Liquid > Run workflow > main.
4. Wait for the green check. Vercel should deploy the updated HTML pages.
5. Reload grimwear.store and test touch-and-drag. Check checkout and admin.

IF THE ACTION REPORTS ORIGINAL ASSETS MISSING
Upload ONLY these two files from optional-original-assets/ to:
launch/GRIM_STORE_RETAIL_V5_1/public/grim-liquid.js
launch/GRIM_STORE_RETAIL_V5_1/public/grim-liquid.css
Then rerun the workflow. These are the exact Bloodline/Abyss fluid assets from
the GRIM Chapter I package dated November 15, 2026. Don't upload them unless
necessary; existing assets may already be the correct version.

SAFE AND REVERSIBLE
The new V1 files remain in the repo but are no longer loaded. No database,
backend, payment, or notification files are changed. Git history preserves
previous revisions. The previous Activate Liquid Glass workflow is still in
GitHub; do not rerun it after restoring the original look.
